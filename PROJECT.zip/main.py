import tkinter as tk
from auth import AuthService
from game_logic import Game 
from gui import RPGInterface
from utils import log_event, COLOR_CYAN, DEBUG_MODE

def main():
    log_event("Uruchamianie gierki...", color=COLOR_CYAN, timestamp=True)

    #tworzy gui za pomocą tkinter
    root = tk.Tk()

    #tworzy obiekt do obsługi logowania
    auth_service = AuthService()

    #zmienna, która będzie przechowywać obiekt interfejsu graficznego; na razie pusta
    app_gui_instance = None

    #Definicje funkcji "callback"
    #Te funkcje będą przekazane do logiki gry (Game),
    #żeby logika gry mogła "powiedzieć" gui (RPGInterface), co ma zrobić,
    #np. wyświetlić wiadomość albo zaktualizować statystyki.
    #To taki sposób komunikacji "w drugą stronę": GUI -> Game -> GUI.

    #Ta funkcja będzie wywoływana przez logikę gry, gdy chce coś wyświetlić w logu GUI
    def gui_log_callback(message):
        if app_gui_instance: app_gui_instance.log_message(message)
        log_event(f"GUI_MSG: {message}", level="DEBUG", timestamp=False)

    #Ta funkcja będzie wywoływana przez logikę gry, gdy chce zaktualizować etykiety ze statusami
    def gui_status_update_callback(player_status, enemy_status, inventory_listing):
        if app_gui_instance: app_gui_instance.update_status_labels(player_status, enemy_status, inventory_listing)

    #Ta funkcja będzie wywoływana przez logikę gry, gdy chce zmienić widoczność przycisków walki
    def gui_combat_buttons_callback(is_active):
        if app_gui_instance: app_gui_instance.update_combat_buttons_visibility(is_active)

    #Koniec definicji funkcji "callback"

    #Tworzy główny obiekt logiki gry (Game)
    #Przekazuje do niego zdefiniowane wyżej funkcje "callback" żeby logika gry mogła komunikować się z gui.
    game_service = Game(
        gui_callback_log=gui_log_callback,
        gui_callback_update_stats=gui_status_update_callback,
        gui_callback_combat_buttons=gui_combat_buttons_callback
    )

    #tera tworzy obiekt gui (RPGInterface)
    #Przekazuje do niego:
    #'root': główne okno aplikacji
    #'auth_service': obiekt do obsługi logowania
    #'game_service': obiekt z logiką gry
    #Dlatego funkcje callback mają warunek 'if app_gui_instance:',
    #bo gdy 'game_service' jest tworzony, 'app_gui_instance' jest jeszcze None.
    app_gui_instance = RPGInterface(root, auth_service, game_service)

    log_event("Aplikacja RPG zainicjalizowana i uruchomiona.", color=COLOR_CYAN)

    #Glowna petla od tkintera tego typu
    root.mainloop()

    #Dopiero po zamknieciu gui:
    log_event("Aplikacja RPG zakończyła działanie.", color=COLOR_CYAN, timestamp=True)

if __name__ == "__main__":
    main()